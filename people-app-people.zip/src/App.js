import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';
import Person from './models/Person';
import Viewer from './componets/Viewer/viewer';
import Editor from './componets/Editor/editor';
import List from './componets/List/list';

class App extends Component {
  constructor(props){
    super(props);

    this.state = {
      person: new Person(1, "Oren", "Levi", 30,"https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png",
       "Male"),

       people: [new Person(1, "Oren", "Levi", 9,"https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png",
       "Male"),
       new Person(2, "Yosi", "Cohen", 2,"https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png",
       "Male"),
       new Person(3, "Tal", "Bla;a", 50,"https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png",
       "Male")]
    }
  }

  onPersonUpdate(person){
    this.setState({
      person: {...person}
    })
  }

  render(){

    // let people = this.state.people.map((person, index)=>{
    //   return <div key={index}>Name: {person.firstName} {person.lastName}</div>
    // })
    return (
      <div className="App">
        {/* <Viewer person={this.state.person}></Viewer>
        <Editor person={this.state.person} onUpdate={this.onPersonUpdate.bind(this)}></Editor> */}

        {/* {people} */}

        {/* {this.state.people.map((person)=>{
          return <div key={person.id}>Name: {person.firstName} {person.lastName}</div>
        })} */}

        <List people={this.state.people}></List>
      </div>
    );
  }
}

export default App;
