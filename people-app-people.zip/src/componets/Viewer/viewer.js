function Viewer(props){
    let icon = null;
    if(props.person.gender == "Male"){
        icon = <img src="./male-user.png" width={30}></img>
    }
    else if(props.person.gender == "Female"){
        icon = <img src="./woman-avatar.png" width={30}></img>
    }

    return <div>
        <h2>Viewer</h2>
        <div>First Name: {props.person.firstName} </div>
        <div>Last Name: {props.person.lastName} </div>
        <div>gender: {props.person.gender} {icon}</div>
        <div style={{color: props.person.age >= 10? 'green' : 'red'}}>age: {props.person.age} </div>
        <img src={props.person.image} width="300"></img>
    </div>
}

export default Viewer;