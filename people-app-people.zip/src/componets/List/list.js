import Item from "./item";

function List(props){

    return  <div>{props.people.map((person)=>{
        return <Item key={person.id} person={person}></Item>
      })}</div>
}


export default List;