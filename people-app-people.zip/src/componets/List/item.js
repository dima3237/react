
function Item(props){

    return <div>Name: {props.person.firstName} {props.person.lastName}</div>
}

export default Item;