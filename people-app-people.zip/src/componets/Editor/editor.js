
import React, { Component } from 'react';

class Editor extends Component {
    constructor(props){
        super(props);
        this.state = {updatedPerson: {...props.person}}
    }

    onInputChange(e){
        let updatedPerson = {...this.state.updatedPerson};
        updatedPerson[e.target.name] = e.target.value;
        this.setState({
            updatedPerson:  updatedPerson
        });
    }

    render(){
        return <div>
            <h2>Editor</h2>
            <div>First Name: <input type="text" name="firstName" value={this.state.updatedPerson.firstName} onChange={this.onInputChange.bind(this)} /></div>
            <div>Last Name: <input type="text"  name="lastName"  value={this.state.updatedPerson.lastName} onChange={this.onInputChange.bind(this)}/></div>
            <div>Gender: <input type="text" name="gender" value={this.state.updatedPerson.gender} onChange={this.onInputChange.bind(this)}/></div>
            <div>Age: <input type="text"  name="age"  value={this.state.updatedPerson.age} onChange={this.onInputChange.bind(this)}/></div>
            <div>Image: <input type="text"  name="image"    value={this.state.updatedPerson.image} onChange={this.onInputChange.bind(this)}/></div>
            <button onClick={()=>this.props.onUpdate(this.state.updatedPerson)}>Update</button>
        </div>
    }
}

export default Editor;