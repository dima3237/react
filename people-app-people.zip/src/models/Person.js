class Person {
    constructor(id=0, fname, lname, age, image, gender){
        this.firstName = fname;
        this.lastName= lname;
        this.age = age;
        this.gender= gender;
        this.image= image;
        this.id =id; 
    }
}

export default Person;