
const API_URL = `${process.env.REACT_APP_SERVER_URL}/${process.env.REACT_APP_MOVIES_ROUTE}/`;

class MoviewService {

    getMovies(){
        return fetch(API_URL)
            .then((response)=> {
            if(response.status != 200){
                throw new Error("Error occured: " + response.status)
            }
            return response.json()
            })
    }

    updateMoviews(){

    }

    deleteMovies(){

    }

    addMovies(){

    }

}

export default MoviewService