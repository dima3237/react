import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
import { MovieList } from './Movies/movie-list/movie-list';
import MoviewService from './services/moviewService';

const API_URL = `${process.env.REACT_APP_SERVER_URL}/${process.env.REACT_APP_MOVIES_ROUTE}/`;

class App extends Component {
   
  constructor(props){
    super(props);
    this.state = {
      selectedMovieInx:-1,
      updatingMovie:null,
      movies:[],
      guess: 51
    }

    this.moviewService = new MoviewService();
  }

  onMovieSelected(selectedInx){
    const updatingMovie = { ...this.state.movies[selectedInx] };
    this.setState({ selectedMovieInx:selectedInx, updatingMovie});
  }

  componentDidMount(){
    this.getMovies();
  }

  getMovies(){   
    // fetch(API_URL)
    //     .then((response)=> {
    //       if(response.status != 200){
    //         throw new Error("Error occured: " + response.status)
    //       }
    //       return response.json()
    //     })
    //     .then((data)=> {
    //       this.setState({movies: data})
    //     })
    //     .catch((error)=> console.log(error))

    this.moviewService.getMovies()
        .then((data)=> {
          this.setState({movies: data})
        })
        .catch((error)=> console.log(error))
  }

  updateMovie(){
    const id = 1;
    fetch(API_URL + id, {
        method: "PUT",
        headers: {
          "Content-Type":'application/json'
        },
        body: JSON.stringify({
          "title": "Toy story 2222222",
          "poster": "http://ia.media-imdb.com/images/M/MV5BMTMwNDU0NTY2Nl5BMl5BanBnXkFtZTcwOTUxOTM5Mw@@._V1._SX214_CR0,0,214,314_.jpg",
          "year": "1997",
          "releaseDate": "1995-11-21T22:00:00.000Z",
          "genres": [
            "Adventure",
            "Animation",
            "Children",
            "Comedy",
            "Fantasy"
          ]
        })
      })
      .then((response)=> {
        if(response.status != 200){
          throw new Error("Error occured: " + response.status)
        }
        this.getMovies();
      })
      .catch((error)=> console.log(error));
  }

  deleteMovie(){
    const id = 1;
    fetch(API_URL + id, {
        method: "DELETE"
      })
      .then((response)=> {
        if(response.status != 200){
          throw new Error("Error occured: " + response.status)
        }
        return response.json()
      })
      .then((data)=> {
        this.getMovies();
      })
      .catch((error)=> console.log(error));
  }

  addMovie(){
      fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type":'application/json'
        },
        body: JSON.stringify({
          "title": "IT22",
          "year": "2017",
          "poster": "http://www.optionated.com/wp-content/uploads/2014/05/it-movie-poster.jpg",
          "releaseDate": null,
          "genres": ["Drama"]
        })
      })
      .then((response)=> {
        if(response.status != 200 && response.status != 201){
          throw new Error("Error occured: " + response.status)
        }
        this.getMovies();
      })
      .catch((error)=> console.log(error));
  }

  // async validate(e){
  //   this.setState({guess: e.target.value * 1});

  //   let promise = new Promise((resolve,reject) => {
  //     setTimeout(() => {
  //        const num = Math.random()*100;
  //        if(num >this.state.guess){
  //          resolve(num);
  //        }
  //        else{
  //          reject(num)
  //        }
  //      },1000);
  //    });

  //    try{ 
  //     let result = await promise;
  //     console.log('Resolve ' + result);
  //    }
  //    catch(error) {
  //     console.log('Reject ' + error);
  //    }
  //   // promise.then((data)=> { console.log('timeout ened ' + data); },
  //   //                 (error)=>{console.log(`error: ${error}`); } )
  // }

  render(){
    const style = {
      borderBottom:'solid 2px black', 
      paddingBottom:'5px'
  }
    return (
      <div className="App">
        <button onClick={this.addMovie.bind(this)}>Add</button>
        <button onClick={this.updateMovie.bind(this)}>Update</button>
        <button onClick={this.deleteMovie.bind(this)}>DELETE</button>
        {/* <input value={this.state.guess} onChange={this.validate.bind(this)} /> */}
         <h1 style={style}>Movie Catalog </h1>
        <section>
            <div className="list">
                <MovieList
                      selectedInx={this.state.selectedMovieInx}
                      itemSelected={this.onMovieSelected.bind(this)}
                      movies={this.state.movies} ></MovieList>
            </div>
        </section>
      </div>
    );
  }
}

export default App;
